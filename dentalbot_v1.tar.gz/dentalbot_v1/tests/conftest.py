"""
Fixture comune pentru testele API.
"""

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.database import Base
from app.deps import get_db
from app.security import password
from app.models import User, UserRole


# Creează o bază de date SQLite in-memory pentru fiecare test
@pytest.fixture(scope="session")
def engine():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False}, future=True)
    Base.metadata.create_all(bind=engine)
    yield engine
    engine.dispose()


@pytest.fixture(scope="function")
def db_session(engine):
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


@pytest.fixture(scope="function")
def client(db_session):
    # Suprascrie dependency-ul get_db pentru a utiliza sesiunea de test
    def _get_db_override():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = _get_db_override
    client = TestClient(app)
    # Introduce un utilizator admin în test DB
    hashed = password.get_password_hash("testpass")
    admin = User(email="admin@test.local", hashed_password=hashed, role=UserRole.ADMIN, active=True)
    db_session.add(admin)
    db_session.commit()
    yield client
    app.dependency_overrides.clear()