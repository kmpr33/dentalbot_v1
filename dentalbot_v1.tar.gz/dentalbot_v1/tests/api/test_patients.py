from fastapi.testclient import TestClient


def get_auth_headers(client: TestClient) -> dict:
    resp = client.post(
        "/auth/login",
        data={"username": "admin@test.local", "password": "testpass"},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    token = resp.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def test_patient_crud(client: TestClient):
    headers = get_auth_headers(client)
    # empty list
    response = client.get("/admin/patients", headers=headers)
    assert response.status_code == 200
    assert response.json() == []
    # create patient
    payload = {"full_name": "John Doe", "phone": "0712345678", "email": "john@example.com"}
    response = client.post("/admin/patients", json=payload, headers=headers)
    assert response.status_code == 201
    patient = response.json()
    assert patient["full_name"] == "John Doe"
    pid = patient["id"]
    # list now should contain one
    response = client.get("/admin/patients", headers=headers)
    assert response.status_code == 200
    assert len(response.json()) == 1
    # get by id
    response = client.get(f"/admin/patients/{pid}", headers=headers)
    assert response.status_code == 200
    assert response.json()["id"] == pid
    # update
    update_payload = {"phone": "0799999999"}
    response = client.patch(f"/admin/patients/{pid}", json=update_payload, headers=headers)
    assert response.status_code == 200
    assert response.json()["phone"] == "0799999999"