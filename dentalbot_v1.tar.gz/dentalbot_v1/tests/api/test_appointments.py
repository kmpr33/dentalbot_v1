from datetime import datetime, timedelta
from fastapi.testclient import TestClient


def get_auth_headers(client: TestClient) -> dict:
    resp = client.post(
        "/auth/login",
        data={"username": "admin@test.local", "password": "testpass"},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    token = resp.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def test_appointment_flow(client: TestClient):
    headers = get_auth_headers(client)
    # create patient and service
    patient_payload = {"full_name": "Alice", "phone": "0700000000"}
    service_payload = {"name": "Detartraj", "description": "Curățare", "duration_min": 30, "price_from": 200.0}
    patient = client.post("/admin/patients", json=patient_payload, headers=headers).json()
    service = client.post("/admin/services", json=service_payload, headers=headers).json()
    # create appointment
    start = datetime.utcnow() + timedelta(days=1)
    end = start + timedelta(minutes=30)
    appt_payload = {
        "patient_id": patient["id"],
        "service_id": service["id"],
        "start_at": start.isoformat(),
        "end_at": end.isoformat(),
    }
    response = client.post("/admin/appointments", json=appt_payload, headers=headers)
    assert response.status_code == 201
    appointment = response.json()
    assert appointment["patient"]["id"] == patient["id"]
    # list appointments
    response = client.get("/admin/appointments", headers=headers)
    assert response.status_code == 200
    appts = response.json()
    assert len(appts) == 1