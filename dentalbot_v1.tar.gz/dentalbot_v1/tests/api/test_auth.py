from fastapi.testclient import TestClient


def test_login_success(client: TestClient):
    response = client.post(
        "/auth/login",
        data={"username": "admin@test.local", "password": "testpass"},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"


def test_login_failure(client: TestClient):
    response = client.post(
        "/auth/login",
        data={"username": "admin@test.local", "password": "wrong"},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert response.status_code == 400