from fastapi.testclient import TestClient


def get_auth_headers(client: TestClient) -> dict:
    resp = client.post(
        "/auth/login",
        data={"username": "admin@test.local", "password": "testpass"},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    token = resp.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def test_service_crud(client: TestClient):
    headers = get_auth_headers(client)
    # empty list
    response = client.get("/admin/services", headers=headers)
    assert response.status_code == 200
    assert response.json() == []
    # create service
    payload = {"name": "Consult", "description": "Consultatie", "duration_min": 30, "price_from": 100.0}
    response = client.post("/admin/services", json=payload, headers=headers)
    assert response.status_code == 201
    service = response.json()
    assert service["name"] == "Consult"
    sid = service["id"]
    # list again
    response = client.get("/admin/services", headers=headers)
    assert response.status_code == 200
    assert len(response.json()) == 1
    # update service
    update_payload = {"duration_min": 45}
    response = client.patch(f"/admin/services/{sid}", json=update_payload, headers=headers)
    assert response.status_code == 200
    assert response.json()["duration_min"] == 45