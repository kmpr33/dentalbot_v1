import datetime

from sqlalchemy.orm import Session

from app.services.calendar import get_available_slots
from app.models import Appointment


def test_get_available_slots(db_session: Session):
    date = datetime.date.today() + datetime.timedelta(days=1)
    slots = get_available_slots(date, 30, db_session)
    # Trebuie să existe cel puțin un slot liber într-o zi fără programări
    assert len(slots) > 0
    # Adaugă o programare care ocupă un slot și verifică că e eliminat
    start = datetime.datetime.combine(date, datetime.time(9, 0))
    end = start + datetime.timedelta(minutes=30)
    appt = Appointment(patient_id=1, service_id=1, start_at=start, end_at=end)
    db_session.add(appt)
    db_session.commit()
    slots_after = get_available_slots(date, 30, db_session)
    # Slotul de la 9:00 nu mai trebuie să apară
    assert start not in slots_after