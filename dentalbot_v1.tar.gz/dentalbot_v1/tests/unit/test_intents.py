from app.services.intents import detect_intent


def test_intent_detection():
    intent, confidence = detect_intent("Vreau o programare pentru mâine")
    assert intent == "programare"
    assert confidence > 0.5
    intent, confidence = detect_intent("Anulez programarea")
    assert intent == "anulare"
    intent, confidence = detect_intent("Care este pretul pentru detartraj?")
    assert intent == "pret"