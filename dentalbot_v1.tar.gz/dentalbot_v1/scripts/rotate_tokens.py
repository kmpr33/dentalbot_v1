#!/usr/bin/env python
"""
Script de rotație a token‑urilor JWT.

Acest script generează o nouă cheie secretă și o afișează. Într-o implementare
reală, ar trebui să actualizeze variabilele de mediu și să invalideze tokenurile
anterioare stocate.
"""

import secrets


def rotate_secret_key() -> str:
    """Generează o nouă cheie secretă random de 64 de caractere hex."""
    return secrets.token_hex(32)


if __name__ == "__main__":
    new_key = rotate_secret_key()
    print("Noua cheie secretă (JWT_SECRET) este:")
    print(new_key)
    print("Actualizați fișierul .env cu această valoare.")