#!/usr/bin/env bash

# Oprește serviciile Docker

docker compose down