#!/usr/bin/env python
"""
Script pentru crearea bazei de date și aplicarea migrărilor.

În această implementare simplificată, folosim SQLAlchemy pentru a crea toate tabelele
definite în `app/models.py`. Pentru utilizarea în producție este recomandat să
se folosească Alembic pentru migrații.
"""

from app.database import Base, engine

def init_db() -> None:
    """Creează toate tabelele în baza de date."""
    Base.metadata.create_all(bind=engine)


if __name__ == "__main__":
    init_db()
    print("Baza de date a fost creată cu succes.")