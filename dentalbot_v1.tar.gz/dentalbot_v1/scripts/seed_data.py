#!/usr/bin/env python
"""
Populatează baza de date cu date inițiale pentru dezvoltare.

Acest script creează:
 - un utilizator admin cu email `admin@clinic.ro` și parolă `admin123` (hash în DB)
 - câteva servicii stomatologice de bază
 - ore de lucru implicite pentru un doctor demo (simplificat: nu sunt stocate în DB în acest schelet)
 - template‑uri de mesaje pentru confirmare și reminder

Rularea repetată a acestui script nu duce la duplicarea datelor (în măsura în care verificările sunt implementate simplu).
"""

import datetime
from sqlalchemy.orm import Session

from app.database import SessionLocal, engine
from app import models, security

def seed() -> None:
    db: Session = SessionLocal()
    try:
        # Creează utilizator admin dacă nu există
        admin_email = "admin@clinic.ro"
        user = db.query(models.User).filter_by(email=admin_email).first()
        if not user:
            hashed = security.password.get_password_hash("admin123")
            user = models.User(email=admin_email, hashed_password=hashed, role=models.UserRole.ADMIN, active=True)
            db.add(user)
            db.commit()
            print(f"Utilizatorul admin creat: {admin_email} / admin123 (resetare obligatorie la prima logare)")
        # Creează servicii de bază
        default_services = [
            {"name": "Consult", "description": "Consultație stomatologică", "duration_min": 30, "price_from": 150.0},
            {"name": "Detartraj", "description": "Curățare profesională (detartraj)", "duration_min": 45, "price_from": 250.0},
            {"name": "Albire", "description": "Albire dentară profesională", "duration_min": 60, "price_from": 500.0},
            {"name": "Obturatie compozit", "description": "Plombă estetică", "duration_min": 45, "price_from": 300.0},
        ]
        for svc in default_services:
            existing = db.query(models.Service).filter_by(name=svc["name"]).first()
            if not existing:
                service = models.Service(
                    name=svc["name"],
                    description=svc["description"],
                    duration_min=svc["duration_min"],
                    price_from=svc["price_from"],
                    visible_channels="all",
                    active=True,
                )
                db.add(service)
        db.commit()
        # Creează template‑uri de mesaje
        templates = [
            {
                "key": "confirmation",
                "locale": "ro",
                "channel": "generic",
                "content": "Salut {{patient_name}},\nProgramarea ta pentru {{service_name}} a fost confirmată pe {{date}} la {{time}}.\nNe vedem la {{clinic_name}}!\nCod rezervare: {{manage_link}}",
            },
            {
                "key": "reminder_24h",
                "locale": "ro",
                "channel": "generic",
                "content": "Bună {{patient_name}}!\nAcesta este un reminder pentru programarea de mâine la {{time}} pentru {{service_name}}.\nDacă dorești să modifici, folosește linkul: {{manage_link}}.",
            },
            {
                "key": "reminder_2h",
                "locale": "ro",
                "channel": "generic",
                "content": "Salut {{patient_name}}, mai sunt două ore până la programarea ta. Te așteptăm la {{clinic_name}} la {{time}}.",
            },
        ]
        for tmpl in templates:
            existing = (
                db.query(models.MessageTemplate)
                .filter_by(key=tmpl["key"], locale=tmpl["locale"], channel=tmpl["channel"])
                .first()
            )
            if not existing:
                template = models.MessageTemplate(
                    key=tmpl["key"],
                    locale=tmpl["locale"],
                    channel=tmpl["channel"],
                    content=tmpl["content"],
                    variables="patient_name,service_name,date,time,clinic_name,manage_link",
                )
                db.add(template)
        db.commit()
        print("Date de bază inserate cu succes.")
    finally:
        db.close()


if __name__ == "__main__":
    seed()