#!/usr/bin/env bash

# Pornește serviciile Docker în modul de dezvoltare

docker compose up --build