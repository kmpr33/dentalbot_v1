"""
Modul de telemetrie simplificat.

Acest modul poate fi extins pentru a trimite statistici către o soluție de monitorizare.
"""

import logging
from datetime import datetime


logger = logging.getLogger("telemetry")


def record_event(name: str, **kwargs) -> None:
    """Înregistrează un eveniment simplu în log."""
    timestamp = datetime.utcnow().isoformat()
    logger.info("event", extra={"event_name": name, "timestamp": timestamp, **kwargs})