"""
Implementare simplă de rate limiting in-memory.

Această implementare nu este recomandată pentru producție; este gândită ca exemplu.
"""

import time
from typing import Dict, Tuple

class SimpleRateLimiter:
    def __init__(self, max_calls: int, period: float) -> None:
        self.max_calls = max_calls
        self.period = period
        self.calls: Dict[str, list[float]] = {}

    def is_allowed(self, key: str) -> bool:
        now = time.time()
        history = self.calls.get(key, [])
        # elimină apelurile mai vechi decât perioada
        history = [t for t in history if now - t < self.period]
        self.calls[key] = history
        if len(history) >= self.max_calls:
            return False
        history.append(now)
        self.calls[key] = history
        return True


# Instanțe globale pentru diverse limitări
per_ip_limiter = SimpleRateLimiter(max_calls=30, period=60)  # 30 requesturi/minut


def rate_limit_dependency(key_func=lambda: "default"):
    """Dependency FastAPI care verifică dacă apelul este permis."""
    def _dependency():
        key = key_func()
        if not per_ip_limiter.is_allowed(key):
            from fastapi import HTTPException, status

            raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="Too many requests")
    return _dependency