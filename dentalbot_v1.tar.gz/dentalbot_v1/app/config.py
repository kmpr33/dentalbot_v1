"""
Gestionarea configurărilor aplicației folosind Pydantic BaseSettings.

Aceste setări sunt citite din variabilele de mediu și, dacă există, din fișierul `.env`.
"""

from functools import lru_cache
from pydantic import BaseSettings


class Settings(BaseSettings):
    app_env: str = "local"
    database_url: str = "sqlite:///./dentalbot.db"
    secret_key: str = "changeme"
    jwt_expires_min: int = 60
    meta_verify_token: str = ""
    meta_page_token: str = ""
    whatsapp_business_id: str = ""
    telegram_bot_token: str = ""
    clinic_name: str = "Clinica Demo"
    base_url: str = "http://localhost:8000"
    log_level: str = "info"
    log_file: str = "dentalbot.log"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache()
def get_settings() -> Settings:
    return Settings()