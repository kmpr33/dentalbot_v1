"""
Implementare simplificată CSRF token pentru rute bazate pe formulare.

Într-o implementare reală, token‑ul trebuie stocat în sesiune și verificat la POST.
"""

import secrets


_current_token: str | None = None


def generate_csrf_token() -> str:
    global _current_token
    _current_token = secrets.token_hex(16)
    return _current_token


def validate_csrf_token(token: str) -> bool:
    return token is not None and token == _current_token