"""
Decoratori pentru permisiuni bazate pe roluri.
"""

from functools import wraps
from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..deps import get_current_user, get_db
from ..models import User, UserRole


def require_role(role: UserRole):
    """Decorare simplă pentru a verifica rolul utilizatorului curent."""

    def decorator(func):
        @wraps(func)
        async def wrapper(*args, current_user: User = Depends(get_current_user), **kwargs):
            if current_user.role != role:
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient privileges")
            return await func(*args, **kwargs)

        return wrapper

    return decorator