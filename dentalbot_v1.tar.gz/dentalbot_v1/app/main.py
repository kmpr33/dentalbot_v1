"""
Punctul de intrare pentru aplicația DentalBot (FastAPI).
"""

from fastapi import Depends, FastAPI, Request, status
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

from .config import get_settings
from .logger import configure_logging
from .routers import auth, health, patients, services, appointments, admin, notifications, messenger, whatsapp, telegram, webhooks
from .services.scheduling import start_scheduler

# Configurează logging-ul la import
configure_logging()

app = FastAPI(title="DentalBot v1", version="1.0.0")

# Montare fișiere statice
app.mount("/static", StaticFiles(directory="app/static"), name="static")

templates = Jinja2Templates(directory="app/templates")


@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    """Landing page simplă."""
    return templates.TemplateResponse("base.html", {"request": request})


# Inclusiv rutele
app.include_router(health.router)
app.include_router(auth.router)
app.include_router(patients.router)
app.include_router(services.router)
app.include_router(appointments.router)
app.include_router(admin.router)
app.include_router(notifications.router)
app.include_router(messenger.router)
app.include_router(whatsapp.router)
app.include_router(telegram.router)
app.include_router(webhooks.router)


@app.on_event("startup")
async def on_startup() -> None:
    # Pornește schedulerul pentru reminder-e
    start_scheduler()