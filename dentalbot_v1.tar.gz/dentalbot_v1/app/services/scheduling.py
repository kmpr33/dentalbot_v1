"""
Gestionarea programării de job-uri (reminder-e etc.) folosind APScheduler.

În acest schelet, implementarea este simplificată și nu pornește un scheduler real.
"""

from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler

from .notifier import send_notification

scheduler: BackgroundScheduler | None = None


def start_scheduler() -> None:
    global scheduler
    if scheduler is None:
        scheduler = BackgroundScheduler()
        scheduler.start()


def schedule_reminder(channel: str, channel_user_id: str, message: str, run_at: datetime) -> None:
    """Programează trimiterea unui mesaj la un moment dat."""
    if scheduler is None:
        start_scheduler()
    scheduler.add_job(send_notification, 'date', run_date=run_at, args=[channel, channel_user_id, message])