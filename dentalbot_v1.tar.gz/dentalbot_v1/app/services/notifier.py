"""
Serviciu de notificări. Trimite mesaje pe canalele suportate.
"""

from . import audit
from ..integrations.meta_client import MetaClient
from ..integrations.telegram_client import TelegramClient


def send_notification(channel: str, channel_user_id: str, message: str) -> None:
    """Trimite un mesaj pe canalul specificat."""
    if channel == "messenger" or channel == "whatsapp":
        client = MetaClient()
        client.send_text(channel_user_id, message, channel=channel)
    elif channel == "telegram":
        client = TelegramClient()
        client.send_text(channel_user_id, message)
    else:
        raise ValueError(f"Canal necunoscut: {channel}")
    # log audit
    audit.log_action(user_id=None, action="send_notification", entity="notification", entity_id=None, metadata={"channel": channel})