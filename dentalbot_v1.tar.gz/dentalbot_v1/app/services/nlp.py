"""
Fallback NLP simplificat.
"""

def analyze_text(text: str) -> dict:
    """Returnează intenția 'unknown' și sentiment neutru."""
    return {"intent": "unknown", "confidence": 0.0, "entities": {}}