"""
Serviciu pentru generarea sloturilor libere în calendar.

Regulile de bază sunt simplificate: ore de lucru 09:00-17:00, pauză 13:00-14:00,
sloturi consecutive în funcție de durata serviciului.
"""

from datetime import datetime, time, timedelta
from typing import List

from sqlalchemy.orm import Session

from ..models import Appointment


WORK_START = time(9, 0)
WORK_END = time(17, 0)
LUNCH_START = time(13, 0)
LUNCH_END = time(14, 0)


def get_available_slots(date: datetime.date, duration_min: int, db: Session) -> List[datetime]:
    """Generează sloturi disponibile pentru o dată și durată.

    Exclude orele în care există deja programări.
    """
    start_dt = datetime.combine(date, WORK_START)
    end_dt = datetime.combine(date, WORK_END)
    delta = timedelta(minutes=duration_min)
    # extrage programările existente din DB
    appointments = db.query(Appointment).filter(
        Appointment.start_at >= start_dt, Appointment.end_at <= end_dt
    ).all()
    busy_intervals = [(appt.start_at, appt.end_at) for appt in appointments]
    slots = []
    current = start_dt
    while current + delta <= end_dt:
        slot_end = current + delta
        # sărind pauza de masă
        if current.time() < LUNCH_END and slot_end.time() > LUNCH_START:
            current = datetime.combine(date, LUNCH_END)
            continue
        # verifică dacă se suprapune cu un interval ocupat
        overlap = False
        for busy_start, busy_end in busy_intervals:
            if not (slot_end <= busy_start or current >= busy_end):
                overlap = True
                break
        if not overlap:
            slots.append(current)
        current = current + timedelta(minutes=15)  # slot every 15 min as default gap
    return slots