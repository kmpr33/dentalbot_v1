"""
Detectarea intențiilor pentru mesajele primite.

Implementarea de mai jos folosește reguli simple (regex) și un fallback minimal.
"""

import re
from typing import Dict, Tuple

from sqlalchemy.orm import Session

from ..models import Conversation, Patient
from ..telemetry import record_event


INTENT_PATTERNS: Dict[str, list[str]] = {
    "programare": [r"\bprogram\w*", r"\bvreau\s+o\s+programare"],
    "reprogramare": [r"\breprogram\w*"],
    "anulare": [r"\banulare\b", r"\banulez"],
    "pret": [r"\bpret\b", r"\bcost"],
    "servicii": [r"\bservicii\b", r"\bserviciu"],
    "adresa": [r"\badresa\b", r"\blocatie"],
    "orar": [r"\borar\b", r"\bprogram\s+de\s+lucru"],
    "urgenta": [r"\burgenta\b"],
    "operator": [r"\boperator\b", r"\buman"],
}


def detect_intent(text: str) -> Tuple[str, float]:
    """Detectează intenția bazată pe regex. Returnează (intent, confidence)."""
    text_lower = text.lower()
    for intent, patterns in INTENT_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, text_lower):
                return intent, 0.9
    return "fallback", 0.1


async def handle_inbound_message(message: dict, db: Session) -> None:
    """Procesare simplificată a unui mesaj inbound. Înregistrează conversația și intenția."""
    text = message.get("text", "") or ""
    intent, confidence = detect_intent(text)
    # Pentru exemplu, doar înregistrăm intenția în log
    record_event("inbound_message", intent=intent, confidence=confidence)
    # Actualizează conversația curentă
    patient_id = None
    # Găsește pacientul după channel_user_id (neimplementat complet)
    # TODO: mapare canal + id la pacient
    # Dacă nu există, nu facem nimic aici.
    return None