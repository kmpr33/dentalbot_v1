"""
Serviciu pentru gestionarea template‑urilor de mesaje.
"""

from typing import Dict, Optional

from jinja2 import Template
from sqlalchemy.orm import Session

from ..models import MessageTemplate


def get_template(db: Session, key: str, locale: str = "ro", channel: str = "generic") -> Optional[MessageTemplate]:
    return (
        db.query(MessageTemplate)
        .filter_by(key=key, locale=locale, channel=channel)
        .first()
    )


def render_template(template_content: str, variables: Dict[str, str]) -> str:
    template = Template(template_content)
    return template.render(**variables)