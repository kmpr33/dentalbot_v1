"""
Serviciu de audit trail. Înregistrează acțiunile utilizatorilor în baza de date.
"""

import json
from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy.orm import Session

from ..database import SessionLocal
from ..models import AuditLog


def log_action(user_id: Optional[int], action: str, entity: str, entity_id: Optional[int], metadata: Dict[str, Any]) -> None:
    db: Session = SessionLocal()
    try:
        log = AuditLog(
            user_id=user_id,
            action=action,
            entity=entity,
            entity_id=entity_id,
            metadata_json=json.dumps(metadata),
            ts=datetime.utcnow(),
        )
        db.add(log)
        db.commit()
    finally:
        db.close()