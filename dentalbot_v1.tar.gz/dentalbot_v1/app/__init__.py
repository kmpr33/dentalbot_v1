"""Pachetul principal pentru aplicația DentalBot."""

from .main import app  # noqa: F401