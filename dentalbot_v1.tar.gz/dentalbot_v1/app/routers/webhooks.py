"""
Router pentru webhooks (Meta și Telegram).

Într‑o implementare reală, se va face validarea semnăturilor și conversia payload‑ului
într‑un format comun. Aici doar înregistrăm evenimentul primit.
"""

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from sqlalchemy.orm import Session

from ..config import get_settings
from ..deps import get_db
from ..services.intents import handle_inbound_message


router = APIRouter(prefix="/webhooks", tags=["webhooks"])


@router.post("/meta")
async def meta_webhook(request: Request, db: Session = Depends(get_db), x_hub_signature: str | None = Header(None)):
    payload = await request.json()
    # TODO: validare semnătură folosind X-Hub-Signature și secretul
    # Normalizare mesaj
    # Aici extragem canalul și user_id din payload pentru exemplificare
    message = {
        "channel": "messenger",
        "channel_user_id": payload.get("sender", {}).get("id"),
        "text": payload.get("message", {}).get("text"),
        "attachments": [],
        "ts": payload.get("timestamp"),
    }
    # Trimitem către handlerul de intenții
    await handle_inbound_message(message, db)
    return {"status": "received"}


@router.post("/telegram")
async def telegram_webhook(request: Request, db: Session = Depends(get_db)):
    payload = await request.json()
    message = {
        "channel": "telegram",
        "channel_user_id": payload.get("message", {}).get("chat", {}).get("id"),
        "text": payload.get("message", {}).get("text"),
        "attachments": [],
        "ts": payload.get("message", {}).get("date"),
    }
    await handle_inbound_message(message, db)
    return {"status": "received"}