"""
Router pentru trimiterea de notificări de test.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..deps import get_db, get_current_user
from ..services.notifier import send_notification


router = APIRouter(prefix="/admin/notifications", tags=["notifications"])


@router.post("/test")
def send_test_notification(channel: str, recipient_id: str, message: str, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    try:
        send_notification(channel=channel, channel_user_id=recipient_id, message=message)
        return {"status": "sent"}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))