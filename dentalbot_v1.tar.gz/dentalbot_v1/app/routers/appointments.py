"""
Rute pentru gestionarea programărilor.
"""

from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..deps import get_db, get_current_user
from ..models import Appointment, AppointmentStatus, Patient, Service
from ..schemas import AppointmentCreate, AppointmentOut, AppointmentUpdate


router = APIRouter(prefix="/admin/appointments", tags=["appointments"])


@router.get("", response_model=List[AppointmentOut])
def list_appointments(
    patient_id: Optional[int] = Query(None),
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    query = db.query(Appointment).order_by(Appointment.start_at)
    if patient_id is not None:
        query = query.filter(Appointment.patient_id == patient_id)
    appointments = query.offset(skip).limit(limit).all()
    return appointments


@router.post("", response_model=AppointmentOut, status_code=status.HTTP_201_CREATED)
def create_appointment(
    payload: AppointmentCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    # verifică existența pacientului și serviciului
    patient = db.query(Patient).filter(Patient.id == payload.patient_id).first()
    service = db.query(Service).filter(Service.id == payload.service_id).first()
    if not patient or not service:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid patient or service")
    appointment = Appointment(**payload.dict())
    db.add(appointment)
    db.commit()
    db.refresh(appointment)
    return appointment


@router.patch("/{appointment_id}", response_model=AppointmentOut)
def update_appointment(
    appointment_id: int,
    payload: AppointmentUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    appointment = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if not appointment:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Appointment not found")
    for key, value in payload.dict(exclude_unset=True).items():
        setattr(appointment, key, value)
    db.commit()
    db.refresh(appointment)
    return appointment