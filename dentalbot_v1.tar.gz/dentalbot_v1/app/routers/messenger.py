"""
Router pentru operațiuni legate de Messenger.
Aceste endpoint‑uri sunt exemple de apel către clientul Meta.
"""

from fastapi import APIRouter, Depends, HTTPException

from ..deps import get_current_user
from ..integrations.meta_client import MetaClient


router = APIRouter(prefix="/messenger", tags=["messenger"])


@router.post("/send")
def send_message(recipient_id: str, message: str, current_user=Depends(get_current_user)):
    client = MetaClient()
    try:
        client.send_text(recipient_id, message)
        return {"status": "sent"}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))