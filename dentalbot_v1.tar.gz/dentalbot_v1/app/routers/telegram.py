"""
Router pentru operațiuni legate de Telegram.
"""

from fastapi import APIRouter, Depends, HTTPException

from ..deps import get_current_user
from ..integrations.telegram_client import TelegramClient


router = APIRouter(prefix="/telegram", tags=["telegram"])


@router.post("/send")
def send_telegram(recipient_id: str, message: str, current_user=Depends(get_current_user)):
    client = TelegramClient()
    try:
        client.send_text(recipient_id, message)
        return {"status": "sent"}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))