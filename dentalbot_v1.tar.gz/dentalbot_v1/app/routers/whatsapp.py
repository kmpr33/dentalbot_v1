"""
Router pentru operațiuni legate de WhatsApp Business.
"""

from fastapi import APIRouter, Depends, HTTPException

from ..deps import get_current_user
from ..integrations.meta_client import MetaClient


router = APIRouter(prefix="/whatsapp", tags=["whatsapp"])


@router.post("/send")
def send_whatsapp(recipient_id: str, message: str, current_user=Depends(get_current_user)):
    client = MetaClient()
    try:
        client.send_text(recipient_id, message, channel="whatsapp")
        return {"status": "sent"}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))