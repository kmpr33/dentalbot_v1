"""
Router pentru funcționalități administrative diverse.
"""

from datetime import date, datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..deps import get_db, get_current_user
from ..models import Appointment, MessageTemplate, Patient, Service
from ..schemas import MessageTemplateCreate, MessageTemplateOut


router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/dashboard")
def get_dashboard(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    """Returnează câteva statistici simple pentru dashboard."""
    today = date.today()
    appointments_today = db.query(Appointment).filter(Appointment.start_at >= datetime.combine(today, datetime.min.time()), Appointment.start_at < datetime.combine(today, datetime.max.time())).count()
    total_patients = db.query(Patient).count()
    total_services = db.query(Service).count()
    return {
        "appointments_today": appointments_today,
        "total_patients": total_patients,
        "total_services": total_services,
    }


@router.get("/templates", response_model=List[MessageTemplateOut])
def list_templates(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    return db.query(MessageTemplate).all()


@router.post("/templates", response_model=MessageTemplateOut, status_code=status.HTTP_201_CREATED)
def create_template(payload: MessageTemplateCreate, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    template = MessageTemplate(**payload.dict())
    db.add(template)
    db.commit()
    db.refresh(template)
    return template


@router.get("/calendar")
def get_calendar(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    """Returnează programările într-un format simplificat pentru calendar."""
    appointments = db.query(Appointment).all()
    events = []
    for appt in appointments:
        events.append({
            "id": appt.id,
            "title": f"{appt.service.name} - {appt.patient.full_name}",
            "start": appt.start_at.isoformat(),
            "end": appt.end_at.isoformat(),
        })
    return events