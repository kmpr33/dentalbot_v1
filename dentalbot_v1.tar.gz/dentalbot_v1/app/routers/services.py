"""
Rute CRUD pentru servicii stomatologice.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from ..deps import get_db, get_current_user
from ..models import Service
from ..schemas import ServiceCreate, ServiceOut, ServiceUpdate


router = APIRouter(prefix="/admin/services", tags=["services"])


@router.get("", response_model=List[ServiceOut])
def list_services(skip: int = 0, limit: int = 100, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    services = db.query(Service).offset(skip).limit(limit).all()
    return services


@router.post("", response_model=ServiceOut, status_code=status.HTTP_201_CREATED)
def create_service(payload: ServiceCreate, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    service = Service(**payload.dict())
    db.add(service)
    db.commit()
    db.refresh(service)
    return service


@router.patch("/{service_id}", response_model=ServiceOut)
def update_service(service_id: int, payload: ServiceUpdate, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    service = db.query(Service).filter(Service.id == service_id).first()
    if not service:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Service not found")
    for key, value in payload.dict(exclude_unset=True).items():
        setattr(service, key, value)
    db.commit()
    db.refresh(service)
    return service