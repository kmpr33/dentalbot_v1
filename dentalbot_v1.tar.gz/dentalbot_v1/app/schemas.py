"""
Schemă Pydantic pentru serializare/deserializare.
"""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, EmailStr, Field

from .models import AppointmentStatus, ChannelEnum, UserRole


# Auth
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    refresh_token: Optional[str] = None


class TokenData(BaseModel):
    user_id: Optional[int] = None
    role: Optional[UserRole] = None


class UserBase(BaseModel):
    email: EmailStr
    role: UserRole


class UserCreate(BaseModel):
    email: EmailStr
    password: str
    role: UserRole = UserRole.RECEPTIE


class UserOut(UserBase):
    id: int
    active: bool
    created_at: datetime

    class Config:
        orm_mode = True


class PatientBase(BaseModel):
    full_name: str
    phone: Optional[str] = None
    telegram_id: Optional[str] = None
    wa_id: Optional[str] = None
    msgr_id: Optional[str] = None
    email: Optional[EmailStr] = None
    notes_internal: Optional[str] = None
    consent_marketing: bool = False


class PatientCreate(PatientBase):
    full_name: str


class PatientUpdate(PatientBase):
    pass


class PatientOut(PatientBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True


class ServiceBase(BaseModel):
    name: str
    description: Optional[str] = None
    duration_min: int
    price_from: Optional[float] = None
    visible_channels: Optional[str] = "all"
    active: bool = True


class ServiceCreate(ServiceBase):
    pass


class ServiceUpdate(ServiceBase):
    pass


class ServiceOut(ServiceBase):
    id: int

    class Config:
        orm_mode = True


class AppointmentBase(BaseModel):
    patient_id: int
    doctor_id: Optional[int] = None
    service_id: int
    start_at: datetime
    end_at: datetime
    status: AppointmentStatus = AppointmentStatus.PENDING
    channel_source: Optional[ChannelEnum] = None
    notes_patient: Optional[str] = None
    notes_staff: Optional[str] = None


class AppointmentCreate(AppointmentBase):
    pass


class AppointmentUpdate(BaseModel):
    start_at: Optional[datetime] = None
    end_at: Optional[datetime] = None
    status: Optional[AppointmentStatus] = None
    notes_patient: Optional[str] = None
    notes_staff: Optional[str] = None


class AppointmentOut(AppointmentBase):
    id: int
    reminder_24h_sent: bool
    reminder_2h_sent: bool
    patient: PatientOut
    service: ServiceOut
    doctor_id: Optional[int]

    class Config:
        orm_mode = True


class MessageTemplateBase(BaseModel):
    key: str
    locale: str = "ro"
    channel: str = "generic"
    content: str
    variables: Optional[str] = None


class MessageTemplateCreate(MessageTemplateBase):
    pass


class MessageTemplateOut(MessageTemplateBase):
    id: int

    class Config:
        orm_mode = True