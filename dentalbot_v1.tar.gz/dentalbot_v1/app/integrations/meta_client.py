"""
Client simplificat pentru API‑urile Meta (Messenger și WhatsApp).

Într‑o implementare reală, acesta ar face apeluri HTTP către API‑urile oficiale. Aici
doar logăm acțiunile pentru demonstrație.
"""

import logging


logger = logging.getLogger(__name__)


class MetaClient:
    def __init__(self) -> None:
        pass

    def send_text(self, recipient_id: str, message: str, channel: str = "messenger") -> None:
        logger.info(f"[MetaClient] Sent text to {recipient_id} on {channel}: {message}")

    def send_quick_replies(self, recipient_id: str, message: str, replies: list[str], channel: str = "messenger") -> None:
        logger.info(f"[MetaClient] Sent quick replies to {recipient_id} on {channel}: {message} | options: {replies}")

    def mark_read(self, recipient_id: str, channel: str = "messenger") -> None:
        logger.info(f"[MetaClient] Mark read for {recipient_id} on {channel}")

    def typing_indicator(self, recipient_id: str, channel: str = "messenger") -> None:
        logger.info(f"[MetaClient] Typing indicator for {recipient_id} on {channel}")

    def send_template(self, recipient_id: str, template_name: str, variables: dict, channel: str = "messenger") -> None:
        logger.info(f"[MetaClient] Sent template {template_name} to {recipient_id} on {channel}: {variables}")