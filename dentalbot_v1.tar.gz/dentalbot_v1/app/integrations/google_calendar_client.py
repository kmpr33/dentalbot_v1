"""
Client de integrare Google Calendar (inactiv implicit).
"""

class GoogleCalendarClient:
    def __init__(self, credentials_path: str | None = None) -> None:
        # neimplementat
        self.credentials_path = credentials_path

    def list_events(self, calendar_id: str):
        raise NotImplementedError

    def create_event(self, calendar_id: str, event_data: dict):
        raise NotImplementedError