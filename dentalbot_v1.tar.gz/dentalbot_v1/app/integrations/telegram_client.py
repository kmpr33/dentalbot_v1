"""
Client simplificat pentru API‑ul Telegram.
"""

import logging

logger = logging.getLogger(__name__)


class TelegramClient:
    def __init__(self) -> None:
        pass

    def send_text(self, chat_id: str, message: str) -> None:
        logger.info(f"[TelegramClient] Sent text to {chat_id}: {message}")

    def send_quick_replies(self, chat_id: str, message: str, replies: list[str]) -> None:
        logger.info(f"[TelegramClient] Sent quick replies to {chat_id}: {message} | options: {replies}")