"""
Configurator de logging structurat cu rotație de fișiere.
"""

import logging
import logging.handlers
import json
from pathlib import Path

from .config import get_settings


def configure_logging() -> None:
    settings = get_settings()
    log_file = settings.log_file
    log_level = getattr(logging, settings.log_level.upper(), logging.INFO)

    # Creează directorul dacă nu există
    log_path = Path(log_file)
    if not log_path.parent.exists():
        log_path.parent.mkdir(parents=True, exist_ok=True)

    handler = logging.handlers.RotatingFileHandler(log_file, maxBytes=5_000_000, backupCount=3)

    class JsonFormatter(logging.Formatter):
        def format(self, record: logging.LogRecord) -> str:
            log_record = {
                "timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%SZ"),
                "level": record.levelname,
                "message": record.getMessage(),
                "logger": record.name,
            }
            if record.exc_info:
                log_record["exc_info"] = self.formatException(record.exc_info)
            return json.dumps(log_record)

    formatter = JsonFormatter()
    handler.setFormatter(formatter)

    root = logging.getLogger()
    root.setLevel(log_level)
    root.addHandler(handler)
    # De asemenea logare în consolă
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    root.addHandler(console)