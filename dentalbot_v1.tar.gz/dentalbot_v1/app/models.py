"""
Definirea modelelor ORM pentru DentalBot.

Folosim SQLAlchemy 2.0 declarative API. Enumerările sunt reprezentate ca
tipuri de text pentru flexibilitate.
"""

import enum
import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import relationship

from .database import Base


class UserRole(str, enum.Enum):
    ADMIN = "ADMIN"
    RECEPTIE = "RECEPTIE"
    DOCTOR = "DOCTOR"


class AppointmentStatus(str, enum.Enum):
    PENDING = "PENDING"
    CONFIRMED = "CONFIRMED"
    RESCHEDULED = "RESCHEDULED"
    CANCELED = "CANCELED"
    DONE = "DONE"


class ChannelEnum(str, enum.Enum):
    messenger = "messenger"
    whatsapp = "whatsapp"
    telegram = "telegram"
    generic = "generic"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    role = Column(Enum(UserRole), nullable=False, default=UserRole.RECEPTIE)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    appointments = relationship("Appointment", back_populates="doctor", foreign_keys="Appointment.doctor_id")


class Patient(Base):
    __tablename__ = "patients"

    id = Column(Integer, primary_key=True, index=True)
    full_name = Column(String(255), nullable=False)
    phone = Column(String(50), nullable=True)
    telegram_id = Column(String(100), nullable=True)
    wa_id = Column(String(100), nullable=True)
    msgr_id = Column(String(100), nullable=True)
    email = Column(String(255), nullable=True)
    notes_internal = Column(Text, nullable=True)
    consent_marketing = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    appointments = relationship("Appointment", back_populates="patient")
    conversations = relationship("Conversation", back_populates="patient")


class Service(Base):
    __tablename__ = "services"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, unique=True)
    description = Column(Text, nullable=True)
    duration_min = Column(Integer, nullable=False)
    price_from = Column(Float, nullable=True)
    visible_channels = Column(String(50), default="all")
    active = Column(Boolean, default=True)

    appointments = relationship("Appointment", back_populates="service")


class Appointment(Base):
    __tablename__ = "appointments"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    doctor_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    service_id = Column(Integer, ForeignKey("services.id"), nullable=False)
    start_at = Column(DateTime, nullable=False)
    end_at = Column(DateTime, nullable=False)
    status = Column(Enum(AppointmentStatus), nullable=False, default=AppointmentStatus.PENDING)
    channel_source = Column(Enum(ChannelEnum), nullable=True)
    notes_patient = Column(Text, nullable=True)
    notes_staff = Column(Text, nullable=True)
    reminder_24h_sent = Column(Boolean, default=False)
    reminder_2h_sent = Column(Boolean, default=False)

    patient = relationship("Patient", back_populates="appointments")
    doctor = relationship("User", back_populates="appointments")
    service = relationship("Service", back_populates="appointments")


class MessageTemplate(Base):
    __tablename__ = "message_templates"

    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(100), nullable=False)
    locale = Column(String(5), default="ro")
    channel = Column(String(50), default="generic")
    content = Column(Text, nullable=False)
    variables = Column(Text, nullable=True)


class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    channel = Column(Enum(ChannelEnum), nullable=False)
    last_intent = Column(String(100), nullable=True)
    last_message_at = Column(DateTime, default=datetime.utcnow)
    sentiment = Column(String(50), nullable=True)

    patient = relationship("Patient", back_populates="conversations")


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String(100), nullable=False)
    entity = Column(String(100), nullable=True)
    entity_id = Column(Integer, nullable=True)
    metadata_json = Column(Text, nullable=True)
    ts = Column(DateTime, default=datetime.utcnow, nullable=False)

    user = relationship("User")